<?php 

// src/OC/PlatformBundle/Event/PlatformEvents.php

namespace OC\PlatformBundle\Event;


final class PlatformEvents
{
	// Je mets le nom de mon évènement dans une constante
	  const POST_MESSAGE = 'oc_platform.post_message';
}